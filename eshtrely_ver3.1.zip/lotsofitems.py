#!/usr/local/bin/python
# -*- coding: utf-8 -*-

from __future__ import unicode_literals
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from xdb import Base, Sheet, User, Suppliers, User, Item, History
import sys

engine = create_engine('sqlite:///x.db')
# Bind the engine to the metadata of the Base class so that the
# declaratives can be accessed through a DBSession instance
Base.metadata.bind = engine
DBSession = sessionmaker(bind=engine)

session = DBSession()

#https://www.python.org/dev/peps/pep-0263/
reload(sys)
sys.setdefaultencoding('utf-8')

# Create Admin user
User1 = User(name="Mahmoud Hegazy", email="mahmod.hagzy@gmail.com")
session.add(User1)
session.commit()



supplier1 = Suppliers(name="Mohamed Khaled", balance =100000,
                  debit_balance =00,
                  credit_balance =100000,
                  company_name ="FWD Egypt",
                  img="/static/profile.png",
                  rate=10,
                  specialization="Metal", title="Business owner",
                  n_id="12489712489714", trust_level="mid",
                  warring=0, mobile="01012344859",
                  mobile1="01012344852", phone="0235555495")

session.add(supplier1)
session.commit()

supplier1 = Suppliers(name="Ahmed Kenawy", balance =00,
                  debit_balance =5000,
                  credit_balance =00,
                  company_name ="Udacity",
                  img="/static/profile.png",
                  rate=10,
                  specialization="Metal", title="Business owner",
                  n_id="12489712489714", trust_level="mid",
                  warring=0, mobile="01012344859",
                  mobile1="01012344852", phone="0223685497")

session.add(supplier1)
session.commit()

supplier1 = Suppliers(name="Mahmoud Hegazy", balance =1000000,
                  debit_balance =00,
                  credit_balance =1000000,
                  company_name ="Web Developers",
                  img="/static/profile.png",
                  rate=10,
                  specialization="Metal", title="Business owner",
                  n_id="12489712489714", trust_level="mid",
                  warring=0, mobile="01012344859",
                  mobile1="01012344852", phone="0224485491")

session.add(supplier1)
session.commit()

supplier1 = Suppliers(name="Amira Yehia", balance =00,
                  debit_balance =1000,
                  credit_balance =00,
                  company_name ="Equa Egypt",
                  img="/static/profile.png",
                  rate=10,
                  specialization="wood", title="Business owner",
                  n_id="12489712489714", trust_level="mid",
                  warring=0, mobile="01012344859",
                  mobile1="01012344852", phone="0286685492")

session.add(supplier1)
session.commit()

supplier1 = Suppliers(name="Syaed Kenawy", balance =00,
                  debit_balance =5000,
                  credit_balance =00,
                  company_name ="Udacity",
                  img="/static/profile.png",
                  rate=10,
                  specialization="Metal", title="Business owner",
                  n_id="12489712489714", trust_level="mid",
                  warring=0, mobile="01012344859",
                  mobile1="01012344852", phone="0223685497")

session.add(supplier1)
session.commit()

supplier1 = Suppliers(name="ahmed amin", balance =30000,
                  debit_balance =00,
                  credit_balance =30000,
                  company_name ="custom Developers",
                  img="/static/profile.png",
                  rate=10,
                  specialization="cars", title="Business owner",
                  n_id="12489712489714", trust_level="mid",
                  warring=0, mobile="01012344859",
                  mobile1="01012344852", phone="0224485491")

session.add(supplier1)
session.commit()

supplier1 = Suppliers(name="Haidy samir", balance =00,
                  debit_balance =1000,
                  credit_balance =00,
                  company_name ="hydra Egypt",
                  img="/static/profile.png",
                  rate=10,
                  specialization="Metal", title="Business owner",
                  n_id="12489712489714", trust_level="mid",
                  warring=0, mobile="01012344859",
                  mobile1="01012344852", phone="0286685492")

session.add(supplier1)
session.commit()


supplier1 = Suppliers(name="Syaed Kenawy", balance =00,
                  debit_balance =5000,
                  credit_balance =00,
                  company_name ="Udacity",
                  img="/static/profile.png",
                  rate=10,
                  specialization="Metal", title="Business owner",
                  n_id="12489712489714", trust_level="mid",
                  warring=0, mobile="01012344859",
                  mobile1="01012344852", phone="0223685497")

session.add(supplier1)
session.commit()

supplier1 = Suppliers(name="ahmed amin", balance =30000,
                  debit_balance =00,
                  credit_balance =30000,
                  company_name ="custom Developers",
                  img="/static/profile.png",
                  rate=10,
                  specialization="cars", title="Business owner",
                  n_id="12489712489714", trust_level="mid",
                  warring=0, mobile="01012344859",
                  mobile1="01012344852", phone="0224485491")

session.add(supplier1)
session.commit()

supplier1 = Suppliers(name="Haidy samir", balance =00,
                  debit_balance =1000,
                  credit_balance =00,
                  company_name ="hydra Egypt",
                  img="/static/profile.png",
                  rate=10,
                  specialization="Metal", title="Business owner",
                  n_id="12489712489714", trust_level="mid",
                  warring=0, mobile="01012344859",
                  mobile1="01012344852", phone="0286685492")

session.add(supplier1)
session.commit()



supplier1 = Suppliers(name="Syaed Kenawy", balance =00,
                  debit_balance =5000,
                  credit_balance =00,
                  company_name ="Udacity",
                  img="/static/profile.png",
                  rate=10,
                  specialization="Metal", title="Business owner",
                  n_id="12489712489714", trust_level="mid",
                  warring=0, mobile="01012344859",
                  mobile1="01012344852", phone="0223685497")

session.add(supplier1)
session.commit()

supplier1 = Suppliers(name="ahmed amin", balance =30000,
                  debit_balance =00,
                  credit_balance =30000,
                  company_name ="custom Developers",
                  img="/static/profile.png",
                  rate=10,
                  specialization="cars", title="Business owner",
                  n_id="12489712489714", trust_level="mid",
                  warring=0, mobile="01012344859",
                  mobile1="01012344852", phone="0224485491")

session.add(supplier1)
session.commit()

supplier1 = Suppliers(name="Haidy samir", balance =00,
                  debit_balance =1000,
                  credit_balance =00,
                  company_name ="hydra Egypt",
                  img="/static/profile.png",
                  rate=10,
                  specialization="Metal", title="Business owner",
                  n_id="12489712489714", trust_level="mid",
                  warring=0, mobile="01012344859",
                  mobile1="01012344852", phone="0286685492")

session.add(supplier1)
session.commit()
print("items has been added!..")